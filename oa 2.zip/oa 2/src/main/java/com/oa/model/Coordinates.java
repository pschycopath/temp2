package com.oa.model;


import jakarta.persistence.*;
import lombok.*;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Coordinates {
    @Id
    private int id;
    private Double lat;
    private Double lng;
}
