package com.oa.model;

// src/main/java/com/example/userapitoh2/entity/Hair.java

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hair {
    @Id
    private int id;
    private String color;
    private String type;
}
