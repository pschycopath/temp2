package com.oa.model;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {
    @Id
    private int id;
    @Column(insertable = false,updatable = false)
    private String address;
    @Column(insertable = false,updatable = false)
    private String city;
    private String state;
    private String stateCode;
    private String postalCode;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "coordinates_id", referencedColumnName = "id")
    private Coordinates coordinates;

    private String country;
}
