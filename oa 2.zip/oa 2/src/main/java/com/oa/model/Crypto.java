package com.oa.model;


import jakarta.persistence.*;
import lombok.*;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Crypto {
    @Id
    private int id;
    private String coin;
    private String wallet;
    private String network;
}
