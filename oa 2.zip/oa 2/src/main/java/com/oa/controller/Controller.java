package com.oa.controller;

import com.oa.dto.UserDTO;
import com.oa.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @Autowired
    UserService userService;


    @GetMapping("/userDetails")
    public UserDTO getUserDetails(@RequestParam int userId) {
        // Get user details from the database
        return userService.getUser(userId);
    }
}
