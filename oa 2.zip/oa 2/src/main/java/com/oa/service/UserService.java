package com.oa.service;

import com.oa.dto.UserDTO;
import com.oa.model.User;
import com.oa.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import jakarta.annotation.PostConstruct;

import java.util.*;

@Service
@RequiredArgsConstructor
public class UserService {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private UserRepository userRepository;

    // Replace with your actual API URL
    private final String USER_API_URL = "https://dummyjson.com/users";

    @PostConstruct
    public void loadUsers() {
        // Fetch users from external API
        Object usersArray = restTemplate.getForObject(USER_API_URL, Object.class);
       Object userList=((LinkedHashMap)usersArray).get("users");

       for(int i=0;i<((ArrayList)userList).size();i++){
          LinkedHashMap userMap=(LinkedHashMap)((ArrayList)userList).get(i);
          for(int j=0;i<userMap.size();j++) {
              User user = new User();
             // user.setId(i);
              user.setFirstName((String)userMap.get("firstName"));
              user.setLastName((String)userMap.get("lastName"));
              user.setMaidenName((String)userMap.get("maidenName"));
              user.setAge((Integer)userMap.get("age"));
              user.setGender((String)userMap.get("gender"));
              user.setEmail((String)userMap.get("email"));
              user.setPhone((String)userMap.get("phone"));
              user.setUsername((String)userMap.get("userName"));
              user.setPassword((String)userMap.get("password"));
              user.setBirthDate((String)userMap.get("birthDate"));
              user.setImage((String)userMap.get("image"));
              user.setBloodGroup((String)userMap.get("bloodGroup"));
              user.setHeight((double)userMap.get("height"));
              user.setWeight((double)userMap.get("weight"));
              user.setEyeColor((String)userMap.get("eyeColor"));
              user.setSsn((String)userMap.get("ssn"));
          }

       }


//       for(int i=0;i<userList.size();i++) {
//           User user=userList.get(i);
//              userRepository.save(user);
//       }
    //   userRepository.saveAll(userList);

//        if (usersArray != null) {
//            List<User> users = userList;
//            userRepository.saveAll(users);
//            System.out.println("Users loaded into H2 database successfully.");
//        } else {
//            System.out.println("No users fetched from the API.");
//        }
    }
    public UserDTO getUser(int userId) {
        Optional<User> user = userRepository.findById((long) userId);
        if (user.isPresent()) {
            User u = user.get();
            UserDTO userDTO = new UserDTO();
            userDTO.setFirstName(u.getFirstName());
            userDTO.setLastName(u.getLastName());
            userDTO.setMaidenName(u.getMaidenName());
            userDTO.setAge(u.getAge());
            userDTO.setGender(u.getGender());
            userDTO.setEmail(u.getEmail());
            userDTO.setPhone(u.getPhone());
            userDTO.setUsername(u.getUsername());
            userDTO.setPassword(u.getPassword());
            userDTO.setBirthDate(u.getBirthDate());
            userDTO.setImage(u.getImage());
            userDTO.setBloodGroup(u.getBloodGroup());
            userDTO.setHeight(u.getHeight());
            userDTO.setWeight(u.getWeight());
            userDTO.setEyeColor(u.getEyeColor());
            userDTO.setIp(u.getIp());
            userDTO.setMacAddress(u.getMacAddress());
            userDTO.setUniversity(u.getUniversity());
            userDTO.setEin(u.getEin());
            userDTO.setSsn(u.getSsn());
            return userDTO;
        } else {
            return null;
        }
    }
}