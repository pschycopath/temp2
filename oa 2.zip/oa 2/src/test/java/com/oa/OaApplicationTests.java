package com.oa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OaApplicationTests {

	@Test
	void contextLoads() {
	}

}
